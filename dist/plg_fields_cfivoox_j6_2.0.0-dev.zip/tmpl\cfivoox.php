<?php
/**
 * @package     Joomla.Plugin
 * @subpackage  Fields.Ivoox
 *
 * @copyright   Copyright (C) 2019 SergioIglesiasNET
 * @license     GNU General Public License v2.0
 * @author 		Sergio Iglesias (@sergiois)
 */

defined('_JEXEC') or die;

if (!$field->value || $field->value == '-1')
{
	return;
}

$rawValue = trim((string) $field->value);
$value = null;

if (preg_match('~(?:go\.ivoox\.com/rf/|_rf_|player_ej_|player_ek_)([0-9]+)~i', $rawValue, $match))
{
	$value = $match[1];
}
elseif (preg_match('~^[0-9]+$~', $rawValue))
{
	$value = $rawValue;
}

if (!$value)
{
	return;
}

$value = htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
$color = preg_replace('/[^a-fA-F0-9]/', '', (string) $field->fieldparams->get('colorivoox', '#ff6600'));
$color = $color ?: 'ff6600';

switch($field->fieldparams->get('player', 'default')){
	case 'html5':
	?>
	<iframe title="iVoox audio player" style="width:100%; height:200px;" class="cfivoox" frameborder="0" allowfullscreen="" scrolling="no" loading="lazy" src="https://www.ivoox.com/player_ej_<?php echo $value; ?>_2_1.html"></iframe>
	<?php
	break;

	case 'html5mini':
	?>
	<iframe title="iVoox audio player" style="width:100%; height:48px;" class="cfivoox" frameborder="0" allowfullscreen="" scrolling="no" loading="lazy" src="https://www.ivoox.com/player_ek_<?php echo $value; ?>_2_1.html"></iframe>
	<?php
	break;

	case 'default':
	default:
	?>
	<iframe title="iVoox audio player" id="audio_<?php echo $value; ?>" frameborder="0" allowfullscreen="" scrolling="no" loading="lazy" style="width:100%; height:200px; border:1px solid #EEE; box-sizing:border-box;" class="cfivoox" src="https://www.ivoox.com/player_ej_<?php echo $value; ?>_6_1.html?c1=<?php echo $color; ?>"></iframe>
	<?php
	break;
}
?>
